import { Component, OnInit } from '@angular/core';
import * as contract from 'truffle-contract';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';
import {Web3Service} from '../util/web3.service';

declare let require: any;
const farmer_artifacts = require('../../../build/contracts/Farmer.json');
const processor_artifacts = require('../../../build/contracts/Processor.json');


@Component({
  selector: 'app-warehouse',
  templateUrl: './warehouse.component.html',
  styleUrls: ['./warehouse.component.css']
})
export class WarehouseComponent implements OnInit {

  userName:string;
  searchText1:string;
  searchText2:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  useridin: any;
  AssetIdin: any;
  Statusin: any;
  certid:any;
  Targetid:any;
  Status:any;
  modal:any;
  NgbdModalContent:any;
  hideAlert:boolean=true;
  myGroup:FormGroup;
  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept=true;
  inboundReject=true;
  moredetails:boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;
  packingdate: any;
  useby: any;
  location: any;
  binlocation: any;
  racktype: any;
  deliverby: any;
  intime: any;
 
  //deepak
  farmer_ID: any;
  Reason:any;
  lot_ID: any;
  ph_ID: any;
  Phlotid: any;
  State: any;
  status:any;
  account:any;
  Farmer: any;
  Processor: any;
  accounts: string[];
  farmerID: any;
  lotID: any;
  state: any;
  phID: any;



  constructor(private router: Router, private apiService:ApiService,private route:ActivatedRoute, private web3Service: Web3Service  ) {
    this.userid=this.route.snapshot.queryParams["userID"]
   }

  
  inboundfn() {
    this.inbound=false;
    this.outbound= true;
    this.moredetails=true;
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
    this.moredetails=true;
  }
  mdetails(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;

  // debugger;
   this.apiService.mdetails(this.AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
     
       this.Targetid=wareHouse.target;
       this.binlocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );

  }
  mdetailswh(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;

  // debugger;
   this.apiService.mdetailswh(this.AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
     
       this.Targetid=wareHouse.target;
       this.binlocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );

  }  
  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }
  
  ngOnInit() {
    console.log('OnInit: ' + this.web3Service);
    console.log(this);
	//this.reloadPage();
	
    this.watchAccount();
      //let win = (window as any);
     /* if(win.location.search !== '?loaded' ) {
          win.location.search = '?loaded';
          win.location.reload();
      }	*/
    console.log("Deepak1",this.account);
	console.log("Deepak 4 pm:",farmer_artifacts);
    this.web3Service.artifactsToContract(farmer_artifacts)
     .then((FarmerAbstraction) => {
        this.Farmer = FarmerAbstraction;
		console.log("DeepakOct8:",FarmerAbstraction);
      });     
	console.log("Deepak 4 pm:",processor_artifacts);
    this.web3Service.artifactsToContract(processor_artifacts)
     .then((ProcessorAbstraction) => {
        this.Processor = ProcessorAbstraction;
		console.log("DeepakOct8:",ProcessorAbstraction);
      });
     //this.testreload();	  	  
	 // this.testreload();
   /* this.myGroup = new FormGroup({
      Lotid:new FormControl(''),
      userid:new FormControl(''),
      AssetId:new FormControl(''),
      status:new FormControl(''),
      Targetid:new FormControl('')})       
	  
            }*/
			
			//reloadPage() {
 // this.router.navigate(['processinghouse'],{queryParams:{userID:this.userid}});
//this.router.navigate(["http://localhost:4200/Farmer"/*, { queryParams: {userID:this.userid}}*/);	  
  }

  watchAccount() {
    this.web3Service.accountsObservable.subscribe((accounts) => {
      this.accounts = accounts;
      this.account = accounts[0];
      console.log("Deepak2",this.account);
	  
	  //this.refreshData();
//      this.refreshBalance();
    });
  }

testreload()
{
  if( window.localStorage )
  {
    if( !localStorage.getItem('firstLoad') )
    {
      localStorage['firstLoad'] = true;
      window.location.reload();
    }  
    else
      localStorage.removeItem('firstLoad');
  }
}    
  
  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }
  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }
  public transfer(binlocation,intime){
//debugger;
    var intimestamp =this.intime;
    var seconds=intimestamp.getTime();
    this.apiService.transfer(this.binlocation)
    .subscribe((response) => {
      if(response){
        var iotdata=response[0];
        var endtimestamp=iotdata.endtime;
        }
     }
    );


    this.assetCreated=true;
    this.assetTransferred=false;
  }
  

  public createOutbound(){
    //debugger;
   this.apiService.createOutbound({"assetid":this.AssetId,"userid":this.userid,"lotid":this.Lotid})
   .subscribe((response) => {
     //debugger;
     if(response){
       this.hideAlert=false;
       // var farmer=response[0];
       // this.AssetId=farmer.assetid;
       // this.userid=farmer.userid;
     }
    }
   );
  }
  
  public getwhdetails(AssetIdin,useridin){
    //debugger;
   this.apiService.getwhdetails(AssetIdin,useridin)
   .subscribe((response) => {
     if(response){
       var processingHouse=response[0];
       this.AssetIdin=processingHouse.assetid;
       this.useridin=processingHouse.userid;
      
     }
    }
   );
  }





  public getwhdetailsoutbound(AssetId){
   //debugger;
   this.apiService.getwhdetailsoutbound(AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
       this.Targetid=wareHouse.target;
       this.binlocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );
  }

//DEEPAK's FUNCTIONS

//DEEPAK's FUNCTIONS INBOUND SEARCH

  async searchphAsset(searchText1, searchText2) {
    console.log('Refreshing balancePH');
    const farmerId = searchText2;
    const lotId = searchText1;	
	//hero:Hero[]=[];
	//farmerID:FarmerID[] = [];
	//var tupleArray: [(num1: Int, num2: Int)] = []

   // var farmerID: [(string1: String, string2: String, int3: Int)] = [];	
	//let stringToSplit = "abc def ghi";
//let x = stringToSplit.split(" ");
//console.log(x[0]);

    try {
      const deployedProcessor = await this.Processor.deployed();
      console.log(deployedProcessor);
      console.log('Account', this.account);
	  console.log('searchText2:',searchText2);
	  console.log('searchText1', searchText1);
	  this.useridin = searchText2;
	  
	  this.AssetIdin = searchText1;
      const farmerID = await deployedProcessor.processState.call(searchText1, searchText2);
      console.log('Farmer ID: ' + farmerID);
	  if (farmerID == 1){
		  this.Statusin = "AssetCreated";
	  }
	  else if (farmerID == 2)
		   {
		  this.Statusin = "AssetTransferred";
	  }
	  else if (farmerID == 3)
		   {
		  this.Statusin = "LotAcceptedbyPH";
	  }
	  else if (farmerID == 4)
		   {
		  this.Statusin = "LotRejectedbyPH";
	  }	 	  
//let stringToSplit = farmerID;
//let x = stringToSplit.split(",");
//StringToSplit.split(",");
//console.log(stringToSplit[0]);		  
	  //console.log(farmerID[0].string1);
	  
	  
	 //console.log('Farmer ID: ' + this.farmerID[0]);	  
	 // console.log('Lot ID: ' + lotID);
	 // console.log('state: ' + state);
	 // console.log('phID ID: ' + phID);
	  
      //this.userid = farmerID;
	 // this.AssetId = lotID;
	 // this.ph_ID = phID;
	  //this.State = state;
	  
    } catch (e) {
      console.log(e);
      /*this.setStatus*/
	  console.log('Error getting balance; see log.');
    }
  } 	   
  
  
//DEEPAK's FUNCTIONS OUTBOUND SEARCH

  async searchAsset(searchText3) {
    console.log('Refreshing balance ph search');
    const phuserid = this.userid;
	//const phuserid = "Ph001";
    //const lotId = AssetId;	
	//hero:Hero[]=[];
	//farmerID:FarmerID[] = [];
	//var tupleArray: [(num1: Int, num2: Int)] = []

   // var farmerID: [(string1: String, string2: String, int3: Int)] = [];	
	//let stringToSplit = "abc def ghi";
//let x = stringToSplit.split(" ");
//console.log(x[0]);

    try {
      const deployedProcessor = await this.Processor.deployed();
      console.log(deployedProcessor);
      console.log('Account', this.account);
	  console.log('AssetId', searchText3);
	  console.log('phuserid', phuserid);
      const resultPHa = await deployedProcessor.processState.call(searchText3, phuserid);
	  console.log("state:",resultPHa);	  
	  const resultPH = resultPHa.toNumber();
	  console.log("state:",resultPH);
      console.log('Processor ID: ' + phuserid);
	  if (resultPH == 1){
		  this.Status = "AssetCreated";
	  }
	  else if (resultPH == 2)
		   {
		  this.Status = "AssetTransferred";
	  }
	  else if (resultPH == 3)
		   {
		  this.Status = "LotAcceptedbyWH";
	  }
	  else if (resultPH == 4)
		   {
		  this.Status = "LotRejectedbyWH";
	  }	  
//let stringToSplit = farmerID;
//let x = stringToSplit.split(",");
//StringToSplit.split(",");
//console.log(stringToSplit[0]);		  
	  //console.log(farmerID[0].string1);
	  
	  
	 //console.log('Farmer ID: ' + this.farmerID[0]);	  
	 // console.log('Lot ID: ' + lotID);
	 // console.log('state: ' + state);
	 // console.log('phID ID: ' + phID);
	  
      //this.userid = farmerID;
	 // this.AssetId = lotID;
	 // this.ph_ID = phID;
	  //this.State = state;
	  
    } catch (e) {
      console.log(e);
      /*this.setStatus*/
	  console.log('Error getting balance; see log.');
    }
  }



//DEEPAK's FUNCTIONS INBOUND ACCEPT
  async whreceivesLot(useridin, AssetIdin) {
    // debugger;
      if (!this.Processor) {
      console.log("Ramu:",this.Processor);
      
        /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
        return;
      }
      console.log("working at 4 36pm:",this.Processor);
      const farmerId = useridin;
      const lotId = AssetIdin;	
  
      console.log('receives asset' + AssetIdin);
  
     // this.setStatus('Initiating transaction... (please wait)');
      try {
        const deployedProcessor = await this.Processor.deployed();
      console.log("deployedProcessor",deployedProcessor);
        const transaction = await deployedProcessor.whreceiveLot.sendTransaction(AssetIdin, useridin, {from: this.account});
  
       if (!transaction) {
          /*this.setStatus*/console.log('Receive asset failed!');
        } else {
          /*this.setStatus*/console.log('Receive asset complete!');
        
        } 
      } catch (e) {
        console.log(e);
      /*  this.setStatus('Error sending coin; see log.');*/
      }
    setTimeout(() => 
  {
      this.searchAsset(AssetIdin);
  },
  5000);

  this.inboundAccept=false;
  this.inboundReject=true;
      
    }
  
//DEEPAK's FUNCTIONS INBOUND REJECT    
   async whrejectsLot(useridin, AssetIdin) {
      if (!this.Processor) {
      console.log("Ramu:",this.Processor);
        /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
        return;
      }
      console.log("working at 4 36pm:",this.Processor);
      const farmerId = useridin;
      const lotId = AssetIdin;	
  
      console.log('receives asset' + AssetIdin);
  
     // this.setStatus('Initiating transaction... (please wait)');
      try {
        const deployedProcessor = await this.Processor.deployed();
      console.log("deployedProcessor",deployedProcessor);
        const transaction = await deployedProcessor.whrejectLot.sendTransaction(AssetIdin, useridin, {from: this.account});
  
       if (!transaction) {
          /*this.setStatus*/console.log('Receive asset failed!');
        } else {
          /*this.setStatus*/console.log('Receive asset complete!');
      
        } 
      } catch (e) {
        console.log(e);
      /*  this.setStatus('Error sending coin; see log.');*/
      }
    setTimeout(() => 
  {
      this.searchAsset(AssetIdin);
  },
  5000);	

  this.inboundReject=false;
  this.inboundAccept=true;
    
    }  


//DEEPAK's FUNCTIONS OUTBOUND CREATE 
    async createWhAsset(AssetId, Phlotid) {
      if (!this.Processor) {
      console.log("Ramu:",this.Processor);
        /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
        return;
      }
      console.log("working at 4 36pm:",this.Processor);
      //const ProcessorId = Phlotid;
    //const AssetId = AssetId;
     // const AssetId = this.AssetId;
    console.log('Processor contract0' + Phlotid + ' to ' + Phlotid);
      console.log('Processor contract2' + AssetId + ' to ' + AssetId);
  
     // this.setStatus('Initiating transaction... (please wait)');
      try {
        const deployedProcessor = await this.Processor.deployed();
      console.log("deployedProcessor",deployedProcessor);
        const transaction = await deployedProcessor.createWhAsset.sendTransaction(Phlotid, AssetId, {from: this.account});
  
       if (!transaction) {
          /*this.setStatus*/console.log('Transaction failed!');
        } else {
          /*this.setStatus*/console.log('Create Asset complete complete!');
        } 
      } catch (e) {
        console.log(e);
      /*  this.setStatus('Error sending coin; see log.');*/
      }
    setTimeout(() => 
  {
      this.searchAssetwh(AssetId);
  },
  3000);		

  this.assetCreated=false;
  this.assetTransferred=true;
    
    }
  

//DEEPAK's FUNCTIONS OUTBOUND CREATE 

   async transferWhAsset(AssetId, Phlotid, Targetid) {
      if (!this.Processor) {
      console.log("Ramu:",this.Processor);
        /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
        return;
      }
      console.log("working at 4 36pm:",this.Processor);
      //const farmerId = userid;
      const lotId = AssetId;	
      const phId = Targetid;
  
      console.log('transfer asset' + phId);
  
     // this.setStatus('Initiating transaction... (please wait)');
      try {
        const deployedProcessor = await this.Processor.deployed();
      console.log("deployedProcessor",deployedProcessor);
        const transaction = await deployedProcessor.transferWhAsset.sendTransaction(Phlotid, AssetId,  Targetid, {from: this.account});
  
       if (!transaction) {
          /*this.setStatus*/console.log('Transfer asset failed!');
        } else {
          /*this.setStatus*/console.log('Transfer asset complete!');
      
        } 
      } catch (e) {
        console.log(e);
      /*  this.setStatus('Error sending coin; see log.');*/
      }
    setTimeout(() => 
  {
      this.searchAssetwh(AssetId);
  },
  3000);		
  this.assetCreated=true;
  this.assetTransferred=false;
    }    


    async searchAssetwh(searchText3) {
      console.log('Refreshing balancePH');
      //const whlotId = searchText4;
      const phlotId = "1000";	
    //hero:Hero[]=[];
    //farmerID:FarmerID[] = [];
    //var tupleArray: [(num1: Int, num2: Int)] = []
  
     // var farmerID: [(string1: String, string2: String, int3: Int)] = [];	
    //let stringToSplit = "abc def ghi";
  //let x = stringToSplit.split(" ");
  //console.log(x[0]);
  
      try {
        const deployedProcessor = await this.Processor.deployed();
        console.log(deployedProcessor);
        console.log('Account', this.account);
      console.log('whlotid:',searchText3);
      console.log('phlotId', phlotId);
      //this.userid;
      this.Targetid = "DistID01";
      this.AssetId = searchText3;
        const farmerID = await deployedProcessor.readWhAsset.call(phlotId, searchText3);
        console.log('Processor ID: ' + farmerID);
		this.Phlotid = phlotId;
      if (farmerID == 1){
        this.Status = "AssetCreated";
      }
      else if (farmerID == 2)
         {
        this.Status = "AssetTransferred";
      }
      else if (farmerID == 3)
         {
        this.Status = "LotAcceptedbyPH";
      }
      else if (farmerID == 4)
         {
        this.Status = "LotRejectedbyPH";
      }	 	  
  //let stringToSplit = farmerID;
  //let x = stringToSplit.split(",");
  //StringToSplit.split(",");
  //console.log(stringToSplit[0]);		  
      //console.log(farmerID[0].string1);
      
      
     //console.log('Farmer ID: ' + this.farmerID[0]);	  
     // console.log('Lot ID: ' + lotID);
     // console.log('state: ' + state);
     // console.log('phID ID: ' + phID);
      
        //this.userid = farmerID;
     // this.AssetId = lotID;
     // this.ph_ID = phID;
      //this.State = state;
      
      } catch (e) {
        console.log(e);
        /*this.setStatus*/
      console.log('Error getting balance; see log.');
      }
    } 




}

