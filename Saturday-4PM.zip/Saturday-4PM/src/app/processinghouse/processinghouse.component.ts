import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';

@Component({
  selector: 'app-processinghouse',
  templateUrl: './processinghouse.component.html',
  styleUrls: ['./processinghouse.component.css']
})
export class ProcessinghouseComponent implements OnInit {

  userName:string;
  searchText1:string;
  searchText2:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  certid:any;
  Targetid:any;
  Status:any;
  modal:any;
  NgbdModalContent:any;
  hideAlert:boolean=true;
  myGroup:FormGroup;
  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept=true;
  inboundReject=true;
  moredetails:boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;
  packingdate: any;
  useby: any;
  location: any;


  constructor(private router: Router, private apiService:ApiService,private route:ActivatedRoute ) {
    this.userid=this.route.snapshot.queryParams["userID"]
   }

  
  inboundfn() {
    this.inbound=false;
    this.outbound= true;
    this.moredetails=true;
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
    this.moredetails=true;
  }
  mdetails(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;

   //debugger;
   this.apiService.mdetails(this.AssetId)
   .subscribe((response) => {
     if(response){
       var processingHouse=response[0];
       this.AssetId=processingHouse.assetid;
       this.userid=processingHouse.userid;
       this.Status=processingHouse.status;
       this.Targetid=processingHouse.target;
       this.packingdate=processingHouse.packingdate;
       this.useby=processingHouse.useby;
       this.location=processingHouse.location;
     }
    }
   );

  }
  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }
  
  ngOnInit() {
  }

  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }
  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }
  transfer(){
    this.assetCreated=true;
    this.assetTransferred=false;
  }
  

  public createOutbound(){
    //debugger;
   this.apiService.createOutbound({"assetid":this.AssetId,"userid":this.userid,"lotid":this.Lotid})
   .subscribe((response) => {
     //debugger;
     if(response){
       this.hideAlert=false;
       // var farmer=response[0];
       // this.AssetId=farmer.assetid;
       // this.userid=farmer.userid;
     }
    }
   );
  }
  
  public getphdetails(AssetId,userid){
    //debugger;
   this.apiService.getphdetails(AssetId,userid)
   .subscribe((response) => {
     if(response){
       var farmer=response[0];
       this.AssetId=farmer.assetid;
       this.userid=farmer.userid;
       //this.Status=farmer.status;
     }
    }
   );
  }


  public getphdetailsoutbound(AssetId){
   //debugger;
   this.apiService.getphdetailsoutbound(AssetId)
   .subscribe((response) => {
     if(response){
       var processingHouse=response[0];
       this.AssetId=processingHouse.assetid;
       this.userid=processingHouse.userid;
       this.Status=processingHouse.status;
       this.Targetid=processingHouse.target;
       this.packingdate=processingHouse.packingdate;
       this.useby=processingHouse.useby;
       this.location=processingHouse.location;
     }
    }
   );
  }

}

