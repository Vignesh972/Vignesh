import { Component, OnInit } from '@angular/core';
import * as contract from 'truffle-contract';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';
import {Web3Service} from '../util/web3.service';

declare let require: any;
const farmer_artifacts = require('../../../build/contracts/Farmer.json');
const processor_artifacts = require('../../../build/contracts/Processor.json');

@Component({
  selector: 'app-distributor',
  templateUrl: './distributor.component.html',
  styleUrls: ['./distributor.component.css']
})
export class DistributorComponent implements OnInit {

  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept:boolean=true;
  inboundReject:boolean=true;
  moredetails : boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;

  userName:string;
  searchText1:string;
  searchText2:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  useridin: any;
  AssetIdin: any;
  Statusin: any;
  certid:any;
  Targetid:any;
  Status:any;
  modal:any;
  NgbdModalContent:any;
  hideAlert:boolean=true;
  myGroup:FormGroup;
 /* inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept=true;
  inboundReject=true;
  moredetails:boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;*/
  packingdate: any;
  useby: any;
  location: any;
  binlocation: any;
  racktype: any;
  deliverby: any;
  intime: any;  
  
  //deepak
  farmer_ID: any;
  Reason:any;
  lot_ID: any;
  ph_ID: any;
  Phlotid: any;
  State: any;
  status:any;
  account:any;
  Farmer: any;
  Processor: any;
  accounts: string[];
  farmerID: any;
  lotID: any;
  state: any;
  phID: any;  
  
  constructor(private router: Router, private apiService:ApiService,private route:ActivatedRoute, private web3Service: Web3Service  ) {
    this.userid=this.route.snapshot.queryParams["userID"]
   }

  ngOnInit() {
    console.log("Deepak1",this.account);
	console.log("Deepak 4 pm:",farmer_artifacts);
    this.web3Service.artifactsToContract(farmer_artifacts)
     .then((FarmerAbstraction) => {
        this.Farmer = FarmerAbstraction;
		console.log("DeepakOct8:",FarmerAbstraction);
      });     
	console.log("Deepak 4 pm:",processor_artifacts);
    this.web3Service.artifactsToContract(processor_artifacts)
     .then((ProcessorAbstraction) => {
        this.Processor = ProcessorAbstraction;
		console.log("DeepakOct8:",ProcessorAbstraction);
      });   
  }

  watchAccount() {
    this.web3Service.accountsObservable.subscribe((accounts) => {
      this.accounts = accounts;
      this.account = accounts[0];
      console.log("Deepak2",this.account);
	  
	  //this.refreshData();
//      this.refreshBalance();
    });
  }  
  
  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }

  inboundfn() {
    this.inbound=false;
    this.outbound= true; 
    this.moredetails=true;   
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
     this.moredetails=true;
  }

  mdetails(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;
  }

  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }

  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }

  public transfer(binlocation,intime){
        this.assetCreated=true;
        this.assetTransferred=false;
      }
	  
//backend

 async distreceivesLot(useridin, AssetIdin) {
	// debugger;
    if (!this.Processor) {
		console.log("Ramu:",this.Processor);
		
      /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
      return;
    }
    console.log("working at 4 36pm:",this.Processor);
    const farmerId = useridin;
    const lotId = AssetIdin;	

    console.log('receives asset' + AssetIdin);

   // this.setStatus('Initiating transaction... (please wait)');
    try {
      const deployedProcessor = await this.Processor.deployed();
	  console.log("deployedProcessor",deployedProcessor);
      const transaction = await deployedProcessor.distreceiveLot.sendTransaction(useridin, AssetIdin, {from: this.account});

     if (!transaction) {
        /*this.setStatus*/console.log('Receive asset failed!');
      } else {
        /*this.setStatus*/console.log('Receive asset complete!');
			
      } 
    } catch (e) {
      console.log(e);
    /*  this.setStatus('Error sending coin; see log.');*/
    }
	setTimeout(() => 
{
    this.searchWHAsset(AssetIdin, useridin);
},
5000);
    this.inboundAccept=false;
    this.inboundReject=true;		
  }

 async distrejectsLot(useridin, AssetIdin) {
    if (!this.Processor) {
		console.log("Ramu:",this.Processor);
      /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
      return;
    }
    console.log("working at 4 36pm:",this.Processor);
    const farmerId = useridin;
    const lotId = AssetIdin;	

    console.log('receives asset' + AssetIdin);

   // this.setStatus('Initiating transaction... (please wait)');
    try {
      const deployedProcessor = await this.Processor.deployed();
	  console.log("deployedProcessor",deployedProcessor);
      const transaction = await deployedProcessor.distrejectLot.sendTransaction(useridin, AssetIdin, {from: this.account});

     if (!transaction) {
        /*this.setStatus*/console.log('Receive asset failed!');
      } else {
        /*this.setStatus*/console.log('Receive asset complete!');
		
      } 
    } catch (e) {
      console.log(e);
    /*  this.setStatus('Error sending coin; see log.');*/
    }
	setTimeout(() => 
{
    this.searchWHAsset(AssetIdin, useridin);
},
5000);	
    this.inboundReject=false;
    this.inboundAccept=true;	
  }  

 async createDistAsset(AssetId, userid) {
    if (!this.Processor) {
		console.log("Ramu:",this.Processor);
      /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
      return;
    }
    console.log("working at 4 36pm:",this.Processor);
    const ProcessorId = userid;
	const lotId = AssetId;
   // const lotId = this.AssetId;
	console.log('Processor contract0' + userid + ' to ' + AssetId);
    console.log('Processor contract2' + lotId + ' to ' + AssetId);

   // this.setStatus('Initiating transaction... (please wait)');
    try {
      const deployedProcessor = await this.Processor.deployed();
	  console.log("deployedProcessor",deployedProcessor);
      const transaction = await deployedProcessor.createAsset.sendTransaction(AssetId, userid, AssetId, {from: this.account});

     if (!transaction) {
        /*this.setStatus*/console.log('Transaction failed!');
      } else {
        /*this.setStatus*/console.log('Create Asset complete complete!');
		
      } 
    } catch (e) {
      console.log(e);
    /*  this.setStatus('Error sending coin; see log.');*/
    }
	setTimeout(() => 
{
    this.searchAsset(AssetId);
},
3000);		
    this.assetCreated=false;
    this.assetTransferred=true;	
  }

 async transferDistAsset(AssetId, userid, Targetid) {
    if (!this.Processor) {
		console.log("Ramu:",this.Processor);
      /*this.setStatus*/console.log('Processor is not loaded, unable to send transaction');
      return;
    }
    console.log("working at 4 36pm:",this.Processor);
    const farmerId = userid;
    const lotId = AssetId;	
    const phId = Targetid;

    console.log('transfer asset' + phId);

   // this.setStatus('Initiating transaction... (please wait)');
    try {
      const deployedProcessor = await this.Processor.deployed();
	  console.log("deployedProcessor",deployedProcessor);
      const transaction = await deployedProcessor.transferAsset.sendTransaction(AssetId, userid,  Targetid, {from: this.account});

     if (!transaction) {
        /*this.setStatus*/console.log('Transfer asset failed!');
      } else {
        /*this.setStatus*/console.log('Transfer asset complete!');
		
      } 
    } catch (e) {
      console.log(e);
    /*  this.setStatus('Error sending coin; see log.');*/
    }
	setTimeout(() => 
{
    this.searchAsset(AssetId);
},
3000);	
	    this.assetCreated=true;
    this.assetTransferred=false;
  }
  
 async searchWHAsset(searchText1, searchText2) {
    console.log('Refreshing balancePH');
    const farmerId = searchText2;
    const lotId = searchText1;	
	//hero:Hero[]=[];
	//farmerID:FarmerID[] = [];
	//var tupleArray: [(num1: Int, num2: Int)] = []

   // var farmerID: [(string1: String, string2: String, int3: Int)] = [];	
	//let stringToSplit = "abc def ghi";
//let x = stringToSplit.split(" ");
//console.log(x[0]);

    try {
      const deployedProcessor = await this.Processor.deployed();
      console.log(deployedProcessor);
      console.log('Account', this.account);
	  console.log('searchText2:',searchText2);
	  console.log('searchText1', searchText1);
	  this.useridin = searchText2;
	  
	  this.AssetIdin = searchText1;
      const respStatus = await deployedProcessor.readWhAsset.call(searchText2, searchText1);
      console.log('respStatus: ' + respStatus);
	  if (respStatus == 1){
		  this.Statusin = "AssetCreated";
	  }
	  else if (respStatus == 2)
		   {
		  this.Statusin = "AssetTransferred";
	  }
	  else if (respStatus == 3)
		   {
		  this.Statusin = "LotAcceptedbyWH";
	  }
	  else if (respStatus == 4)
		   {
		  this.Statusin = "LotRejectedbyWH";
	  }	 
	  	  else if (respStatus == 5)
		   {
		  this.Statusin = "LotRecalled";
	  }	
//let stringToSplit = farmerID;
//let x = stringToSplit.split(",");
//StringToSplit.split(",");
//console.log(stringToSplit[0]);		  
	  //console.log(farmerID[0].string1);
	  
	  
	 //console.log('Farmer ID: ' + this.farmerID[0]);	  
	 // console.log('Lot ID: ' + lotID);
	 // console.log('state: ' + state);
	 // console.log('phID ID: ' + phID);
	  
      //this.userid = farmerID;
	 // this.AssetId = lotID;
	 // this.ph_ID = phID;
	  //this.State = state;
	  
    } catch (e) {
      console.log(e);
      /*this.setStatus*/
	  console.log('Error getting balance; see log.');
    }
  } 	  

 async searchAsset(searchText3) {
    console.log('Refreshing balance ph search');
    const phuserid = this.userid;
	//const phuserid = "Ph001";
    //const lotId = AssetId;	
	//hero:Hero[]=[];
	//farmerID:FarmerID[] = [];
	//var tupleArray: [(num1: Int, num2: Int)] = []

   // var farmerID: [(string1: String, string2: String, int3: Int)] = [];	
	//let stringToSplit = "abc def ghi";
//let x = stringToSplit.split(" ");
//console.log(x[0]);

    try {
      const deployedProcessor = await this.Processor.deployed();
      console.log(deployedProcessor);
      console.log('Account', this.account);
	  console.log('AssetId', searchText3);
	  console.log('phuserid', phuserid);
      const respStatusa = await deployedProcessor.processState.call(searchText3, phuserid);
	  console.log("state:",respStatusa);	  
	  const respStatus = respStatusa.toNumber();
	  console.log("state:",respStatus);
      console.log('Processor ID: ' + phuserid);
	  if (respStatus == 1){
		  this.Status = "AssetCreated";
	  }
	  else if (respStatus == 2)
		   {
		  this.Status = "AssetTransferred";
	  }
	  else if (respStatus == 3)
		   {
		  this.Status = "LotAcceptedbyWH";
	  }
	  else if (respStatus == 4)
		   {
		  this.Status = "LotRejectedbyWH";
	  }	 
	  	  else if (respStatus == 5)
		   {
		  this.Status = "LotRecalled";
	  }	  
//let stringToSplit = farmerID;
//let x = stringToSplit.split(",");
//StringToSplit.split(",");
//console.log(stringToSplit[0]);		  
	  //console.log(farmerID[0].string1);
	  
	  
	 //console.log('Farmer ID: ' + this.farmerID[0]);	  
	 // console.log('Lot ID: ' + lotID);
	 // console.log('state: ' + state);
	 // console.log('phID ID: ' + phID);
	  
      //this.userid = farmerID;
	 // this.AssetId = lotID;
	 // this.ph_ID = phID;
	  //this.State = state;
	  
    } catch (e) {
      console.log(e);
      /*this.setStatus*/
	  console.log('Error getting balance; see log.');
    }
  }
  
 async searchStateAsset(AssetId, userid) {
    console.log('Refreshing balance');
    const farmerId = "Far001";
    const lotId = AssetId;	
	//hero:Hero[]=[];
	//farmerID:FarmerID[] = [];
	//var tupleArray: [(num1: Int, num2: Int)] = []

   // var farmerID: [(string1: String, string2: String, int3: Int)] = [];	
	//let stringToSplit = "abc def ghi";
//let x = stringToSplit.split(" ");
//console.log(x[0]);

    try {
      const deployedProcessor = await this.Processor.deployed();
      console.log(deployedProcessor);
      console.log('Account', this.account);
      const farmerID = await deployedProcessor.processState.call(farmerId, lotId);
      console.log('Farmer ID: ' + farmerID);
	  if (farmerID == 1){
		  this.Status = "AssetCreated";
	  }
	  else if (farmerID == 2)
		   {
		  this.Status = "AssetTransferred";
	  }
//let stringToSplit = farmerID;
//let x = stringToSplit.split(",");
//StringToSplit.split(",");
//console.log(stringToSplit[0]);		  
	  //console.log(farmerID[0].string1);
	  
	  
	 //console.log('Farmer ID: ' + this.farmerID[0]);	  
	 // console.log('Lot ID: ' + lotID);
	 // console.log('state: ' + state);
	 // console.log('phID ID: ' + phID);
	  
      //this.userid = farmerID;
	 // this.AssetId = lotID;
	 // this.ph_ID = phID;
	  //this.State = state;
	  
    } catch (e) {
      console.log(e);
      /*this.setStatus*/
	  console.log('Error getting balance; see log.');
    }
  } 	  

	  
}

